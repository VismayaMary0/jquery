$(function() {
  // jQuery goes here...

  // Uncomment this line to fade out the red box on page load
  // $(".red-box").fadeOut(3000);
  // $(".green-box").fadeOut(4000);
  // $(".blue-box").fadeOut(5000);
  // $(".red-box").fadeIn(3000);
  // $(".green-box").fadeIn(4000);
  // $(".blue-box").fadeIn(5000);
  // $(".red-box").fadeTo(3000,.2); // (time,opacity)
  // $(".green-box").fadeTo(4000,.5);
  // $(".blue-box").fadeTo(5000,.8);
  // $(".red-box").slideToggle(2000);
  // $(".red-box").slideToggle(2000);
  // $(".blue-box").animate({
  //   marginLeft:"200px",
  //   opacity:"0",
  //   height:"50px",
  //   width:"50px",
  //   marginTop:"25px"
  // },1000);
  setInterval(function() {
    $(".red-box").slideToggle(2000); // Toggle slide effect every 2 seconds
}, 2000); // Interval of 2 seconds

});